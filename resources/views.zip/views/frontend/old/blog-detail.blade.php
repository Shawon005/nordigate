@extends('frontend.master')
  @section('content')
    <section class="page-title" style="background-image:url({{asset('')}}frontend/images/background/bg-pallarax.jpg)">
        <div class="auto-container">
			<h2>Regional Manager & limited time management</h2>
			<ul class="bread-crumb clearfix">
				<li><a href="{{route('home')}}">Home</a></li>
				<li>Blog Detail</li>
			</ul>
        </div>
    </section>
    <!-- End Page Title -->
	
	<!-- Sidebar Page Container -->
    <div class="sidebar-page-container">
    	<div class="auto-container">
        	<div class="row clearfix">
				
				<!--Content Side-->
                <div class="content-side col-xl-9 col-lg-8 col-md-12 col-sm-12">
                	<div class="blog-single">
						<div class="inner-box">
							<div class="image">
								<img src="{{asset('')}}frontend/images/tour/tour-4.jpg" alt="" />
							</div>
							<div class="lower-content">
								<ul class="post-meta">
									<li><span class="icon fa-solid fa-clock fa-fw"></span>September 12, 2020</li>
									<li><span class="icon fa-solid fa-user fa-fw"></span>by <strong>admin</strong></li>
									<li><span class="icon fa-solid fa-tag fa-fw"></span>Medical</li>
								</ul>
								<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum The man, who is in a stable condition inhospital, has "potentially life-changing injuries" after the overnight attack in Garvagh, County Lonodonderry. He was shot in the arms and legs."What sort of men would think it is accepttable to subject a young girl to this level of brutality and violence?</p>
								<p>"Every child has the right to feel safe and protected in their own home - how is this poor child going to sleep tonight or in coming nights? What are the long term effects on her going to be?"</p>
								<h4>Content without backward-compatible data.</h4>
								<p>"There is absolutely no justification for an attack like this in our communities and we must all work together to bring those responsible to justice and to stop this from happening to another child." Their community. I wonder how they wou if their own child witnessed such a level of violence?</p>
								<p>Earlier this month, <span>the PSNI launched a hard-hitting advertisement campaign</span> aimed at changing public attitudes to paramilitary attacks.</p>
								<div class="two-column">
									<div class="row clearfix">
										<!-- Column -->
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<div class="lower-image">
												<img src="{{asset('')}}frontend/images/city/25816508131_00e16429b8_o.jpg" alt="" />
											</div>
										</div>
										<!-- Column -->
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<div class="lower-image">
												<img src="{{asset('')}}frontend/images/city/26003147786_a04226cd2f_o.jpg" alt="" />
											</div>
										</div>
									</div>
								</div>
								<h4>A Kentucky woman who was accused last year.</h4>
								<p>The intruders chased the girl in the house and threatened her when she hid from them, according to the PSNI Limavady Facebook page. "She came out petrified with her Piggy Bank, HER PIGGY BANK! hoping that the men would take it and leave her dad alone," one outraged officer wrote. Denounce with righteous indignation and dislike men who are so beguiled & demoralized our power of pleasure is to be welcomed. Denounce with the indignation and dislike men who are so beguiled & demoralized our power of choice.</p>
								<blockquote>
									“What sort of men would think it is acceptable to subject to this level of <br> brutality and violence? an attack like thiop.”
									<span class="designation">Neil Borton</span>
								</blockquote>
								<p>The intruders chased the girl in the house and threatened her when she hid from them, according to the PSNI to Limavady Facebook page.</p>
								<p>"She came out petrified with her Piggy Bank, HER PIGGY BANK! hoping that the men would take it and leave her dad alone," one outraged officer wrote. especially in capital projects and the suppliers and consultants that work for you know the value of a customer like that. As a consultant executing two projects for a large multinational, I realise how very difficult it sometimes can be on the receiving-end.</p>
							</div>
							
							<!-- Post Share Options-->
							<div class="post-share-options">
								<div class="post-share-inner d-flex justify-content-between flex-wrap">
									<div class="post-tags"><span>Tags: </span><a href="#">Business</a> <a href="#">Life</a> <a href="#">truck</a> <a href="#">Techniq</a></div>
									<ul class="social-links clearfix">
										<li class="facebook"><a href="#" class="fa-brands fa-facebook-f fa-fw"></a></li>
										<li class="twitter"><a href="#" class="fa-brands fa-twitter fa-fw"></a></li>
										<li class="google-plus"><a href="#" class="fa-brands fa-google fa-fw"></a></li>
										<li class="dribble"><a href="#" class="fa-brands fa-dribbble fa-fw"></a></li>
									</ul>
								</div>
							</div>
							
							<!-- New Posts -->
							<div class="new-posts">
								<div class="d-flex justify-content-between align-items-center flex-wrap">
									<div class="left-box">
										<a class="prev-post" href="#"><span class="fa fa-angle-double-left"></span> Previous Post</a><br>
										<a href="#" class="prev-post-thumb">
											<span class="thumb-image"><img src="{{asset('')}}frontend/images/resource/news-10.jpg" alt="" /></span>
											Revitalising your people in to a <br> retail downturn.
										</a>
									</div>
									<div class="right-box">
										<a class="next-post pull-right" href="#">Next Post <span class="fa fa-angle-double-right"></span></a><br>
										<a href="#" class="next-post-thumb">
											<span class="thumb-image"><img src="{{asset('')}}frontend/images/resource/news-11.jpg" alt="" /></span>
											Organisational teams of the are <br> just like families.
										</a>
									</div>
								</div>
							</div>
							
							<!-- Comments Area -->
							<!-- <div class="comments-area">
								<div class="group-title">
									<h6>Comment (2)</h6>
								</div>
								
								<div class="comment-box">
									<div class="comment">
										<div class="author-thumb"><img src="{{asset('')}}frontend/images/resource/author-12.jpg" alt=""></div>
										<div class="comment-inner clearfix">
											<div class="comment-info clearfix"><strong>Riva Collins</strong><div class="comment-time"> November 19, 2019 at 11:00 am </div></div>
											<div class="text">It’s no secret that the digital industry is booming. From exciting startups to need ghor global and brands, companies are reaching out.</div>
											<a class="comment-reply" href="#">Reply <span class="fa fa-angle-right"></span></a>
										</div>
									</div>
								</div> -->

								<!-- Comment Box -->
								<!-- <div class="comment-box">
									<div class="comment">
										<div class="author-thumb"><img src="{{asset('')}}frontend/images/resource/author-13.jpg" alt=""></div>
										<div class="comment-inner clearfix">
											<div class="comment-info clearfix"><strong>Obila Doe</strong><div class="comment-time"> November 22, 2019 at 10:00 pm </div></div>
											<div class="text">It’s no secret that the digital industry is booming. From exciting startups to need ghor hmiu global and brands, companies are reaching out.</div>
											<a class="comment-reply" href="#">Reply <span class="fa fa-angle-right"></span></a>
										</div>
									</div>
								</div>

							</div> -->
							<!-- End Comments Area -->
							
							<!-- Comment Form -->
							<!-- <div class="comment-form">
								<div class="group-title">
									<h6>Post A Comment</h6>
								</div> -->
								<!-- Comment Form -->
								<!-- <form method="post" action="blog.html">
									<div class="group-text">Your email address will not be published *</div>
									<div class="row clearfix">
										
										<div class="col-lg-4 col-md-4 col-sm-4 form-group">
											<input type="text" name="username" placeholder="Name*" required>
										</div>
										
										<div class="col-lg-4 col-md-4 col-sm-4 form-group">
											<input type="email" name="email" placeholder="Email*" required>
										</div>
										
										<div class="col-lg-4 col-md-4 col-sm-4 form-group">
											<input type="text" name="text" placeholder="Mobile*" required>
										</div>
										
										<div class="col-lg-12 col-md-12 col-sm-12 form-group">
											<div class="check-box"><input type="checkbox" name="shipping-option" id="account-option"> &ensp; <label for="account-option">Save my details in this browser for the next time I comment.</label></div>
										</div>
										
										<div class="col-lg-12 col-md-12 col-sm-12 form-group">
											<textarea name="message" placeholder="Your Comment here..."></textarea>
										</div>
										
										<div class="col-lg-4 col-md-4 col-sm-12 form-group">
											<button class="btn-style-seven theme-btn">
												<span class="btn-wrap">
													<span class="text-one">Post Comment</span>
													<span class="text-two">Post Comment</span>
												</span>
											</button>
										</div>
										
									</div>
								</form>
									
							</div> -->
							<!--End Comment Form -->
							
						</div>
					</div>
				</div>
				
				<!--Sidebar Side-->
                <div class="sidebar-side col-xl-3 col-lg-4 col-md-12 col-sm-12">
                	<aside class="sidebar sticky-top">
						
						<!-- Search -->
                        <div class="sidebar-widget search-box">
                        	<form method="post" action="{{route('contact')}}">
                                <div class="form-group">
                                    <input type="search" name="search-field" value="" placeholder="Search..." required>
                                    <button type="submit"><span class="icon fa fa-search"></span></button>
                                </div>
                            </form>
						</div>
						
						<!--Blog Category Widget-->
                        <div class="sidebar-widget sidebar-blog-category">
                            <div class="sidebar-title">
                                <h4>Categories</h4>
                            </div>
                            <ul class="blog-cat">
                                <li><a href="#">Envato <span>3</span></a></li>
                                <li><a href="#">Themeforest <span>2</span></a></li>
                                <li><a href="#">Graphicriver <span>8</span></a></li>
                            </ul>
                        </div>
						
						<!-- Popular Post Widget-->
                        <div class="sidebar-widget popular-posts">
                            <div class="sidebar-title">
                                <h4>Recent News</h4>
                            </div>
							
							<article class="post">
								<figure class="post-thumb"><img src="{{asset('')}}frontend/images/resource/post-thumb-4.jpg" alt=""><a href="blog-detail.html" class="overlay-box"><span class="icon fa fa-link"></span></a></figure>
								<div class="text"><a href="blog-detail.html">Zechsal Magnesium flakes especially...</a></div>
								<div class="post-info">February 12, 2023</div>
							</article>
							
							<article class="post">
								<figure class="post-thumb"><img src="{{asset('')}}frontend/images/resource/post-thumb-5.jpg" alt=""><a href="blog-detail.html" class="overlay-box"><span class="icon fa fa-link"></span></a></figure>
								<div class="text"><a href="blog-detail.html">Finding a way to separate ‘work’ ...</a></div>
								<div class="post-info">February 12, 2023</div>
							</article>
							
							<article class="post">
								<figure class="post-thumb"><img src="{{asset('')}}frontend/images/resource/post-thumb-6.jpg" alt=""><a href="blog-detail.html" class="overlay-box"><span class="icon fa fa-link"></span></a></figure>
								<div class="text"><a href="blog-detail.html">Hunching over desk can cause pain.</a></div>
								<div class="post-info">February 12, 2023 </div>
							</article>
							
						</div>
						
						<!-- Archive Widget -->
                        <div class="sidebar-widget sidebar-blog-category">
                            <div class="sidebar-title">
                                <h4>Archive</h4>
                            </div>
                            <ul class="blog-cat">
                                <li><a href="#">November 2019 <span>5</span></a></li>
                                <li><a href="#">February 2020 <span>6</span></a></li>
                                <li><a href="#">September 2019 <span>8</span></a></li>
                            </ul>
                        </div>
						
						<!--Gallery Widget-->
                        <div class="sidebar-widget instagram-widget">
                            <div class="sidebar-title">
                                <h4>Gallery</h4>
                            </div>
							<div class="images-outer clearfix">
                                <!--Image Box-->
                                <figure class="image-box"><a href="images/gallery/project-1.jpg" class="lightbox-image" data-caption="" data-fancybox="images" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="{{asset('')}}frontend/images/gallery/instagram-1.jpg" alt=""/></a>
                                </figure>
                                <!--Image Box-->
                                <figure class="image-box"><a href="images/gallery/project-2.jpg" class="lightbox-image" data-caption="" data-fancybox="images" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="{{asset('')}}frontend/images/gallery/instagram-2.jpg" alt=""/></a>
								</figure>
                                <!--Image Box-->
                                <figure class="image-box"><a href="images/gallery/project-3.jpg" class="lightbox-image" data-caption="" data-fancybox="images" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="{{asset('')}}frontend/images/gallery/instagram-3.jpg" alt=""/></a>
                                </figure>
                                <!--Image Box-->
                                <figure class="image-box"><a href="images/gallery/project-4.jpg" class="lightbox-image" data-caption="" data-fancybox="images" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="{{asset('')}}frontend/images/gallery/instagram-4.jpg" alt=""/></a>
                                </figure>
                                <!--Image Box-->
                                <figure class="image-box"><a href="images/gallery/project-5.jpg" class="lightbox-image" data-caption="" data-fancybox="images" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="{{asset('')}}frontend/images/gallery/instagram-5.jpg" alt=""/></a>
                                </figure>
                                <!--Image Box-->
                                <figure class="image-box"><a href="images/gallery/project-6.jpg" class="lightbox-image" data-caption="" data-fancybox="images" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="{{asset('')}}frontend/images/gallery/instagram-6.jpg" alt=""/></a>
                                </figure>
                            </div>
						</div>
						
						<!-- Tags Widget-->
                        <div class="sidebar-widget popular-tags">
                            <div class="sidebar-title">
                                <h4>Tags</h4>
                            </div>
							<a href="#">Map</a>
							<a href="#">Cloud</a>
							<a href="#">Builder</a>
							<a href="#">Tower</a>
							<a href="#">Truck</a>
						</div>
						
					</aside>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- Footer -->
	@endsecction